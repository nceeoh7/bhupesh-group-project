const getG = async (req, res) => {
  let user = await User.findById(req.session.userId).populate('appointmentId');
  if (user.licenseNumber === `default${user.username}`) {
    res.redirect('/g2');
  } else {
    let currentDate = new Date();
    currentDate.setHours(
      currentDate.getHours() - currentDate.getTimezoneOffset() / 60
    );
    currentDate = new Date(currentDate.toISOString().split('T')[0]);
    const appointmentsList = await Appointment.find({
      isTimeSlotAvailable: true,
      appointmentDate: { $gte: currentDate },
    });
    if (user.appointmentId) {
      appointmentsList.push(user.appointmentId);
    }
    const appointments = appointmentsList
      ? appointmentsList
          .map(
            (appointment) =>
              `${appointment.appointmentDate.toISOString().split('T')[0]}|${
                appointment.appointmentTime
              }|${appointment._id}`
          )
          .join()
      : '';
    res.render('g', { user, appointments, errors: [] });
  }
};

const postG = async (req, res) => {
  const {
    make,
    model,
    year,
    plateNumber,
    appointmentDate,
    appointmentTime,
    appointments,
  } = req.body;

  const user = await User.findById(req.session.userId);
  const carDetails = { make, model, year, plateNumber };

  const appointmentId = appointments
    ?.split(',')
    .filter((appointment) =>
      appointment.includes(`${appointmentDate}|${appointmentTime}|`)
    )[0]
    .split('|')[2];

  try {
    if (new Date(dob).getFullYear() > new Date().getFullYear())
      throw new RangeError('Please provide valid date of birth');

    if (user.appointmentId && user.testType == 'G') {
      await User.findByIdAndUpdate(
        req.session.userId,
        { appointmentId, carDetails },
        {
          runValidators: true,
          context: 'query',
        }
      );
      await Appointment.findByIdAndUpdate(user.appointmentId, {
        isTimeSlotAvailable: true,
      });
    } else {
      const { firstName, lastName, dob, age, licenseNumber } = user;
      await User.create({
        firstName,
        lastName,
        age,
        dob,
        licenseNumber,
        testType: 'G',
        appointmentId,
        carDetails,
      });
    }

    await Appointment.findByIdAndUpdate(appointmentId, {
      isTimeSlotAvailable: false,
    });

    return res.redirect('/g');
  } catch (error) {
    let errors = Object.keys(error.errors).map((key) => {
      return error.errors[key].message;
    });
    user.appointmentId = { appointmentDate, appointmentTime };
    user.carDetails = carDetails;
    return res.render('g', { user, errors });
  }
};

module.exports = { getG, postG };
